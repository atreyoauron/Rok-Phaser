const SplashScreen = new Phaser.Scene('splashscreen');

SplashScreen.create = function() {

}

SplashScreen.create = function() {

}

SplashScreen.update = function() {

}

export default SplashScreen;