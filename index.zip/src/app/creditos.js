const Creditos = new Phaser.Scene('creditos');

Creditos.preload = function() {

}

Creditos.create = function() {

}

Creditos.update = function() {

}

export default Creditos;