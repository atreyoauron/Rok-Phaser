const Menu = new Phaser.Scene('menu');

Menu.preload = function() {

}

Menu.create = function() {

}

Menu.update = function() {

}

export default Menu;